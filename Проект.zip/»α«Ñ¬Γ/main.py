from flask import Flask, render_template, redirect, request

from forms.user import RegisterForm
from forms.login import LoginForm
from data.news import News
from data.users import User
from data import db_session

app = Flask(__name__)
app.config['SECRET_KEY'] = '40d1649f-0493-4b70-98ba-98533de7710b'


def main():
    db_session.global_init("db/blogs.db")
    app.run()


@app.route('/')
def index():
    return render_template("Mai_main_page.html")


@app.route('/main/')
def ind():
    return render_template("main_page.html")


@app.route('/register/', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/main/')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        name_log = form.username.data
        passw = form.password.data
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.hashed_password == passw).first():
            return redirect('/main/')
        else:
            return render_template('login.html', title='Авторизация', form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route("/news_page/")
def news():
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.is_private != True)
    return render_template("index.html", news=news)


@app.route('/constellations_select/', methods=['GET', 'POST'])
def a2():
    list = ['Андромеда', 'Близнецы', 'Большая Медведица', 'Возничий', 'Волопас', 'Волосы Вероники', 'Геркулес',
            'Гончие Псы', 'Дельфин', 'Дракон', 'Жираф', 'Кассиопея', 'Лебедь', 'Лев', 'Лира', 'Лисичка',
            'Малая Медведица', 'Малый Конь', 'Малый Лев', 'Малый Пес', 'Овен', 'Персей', 'Рак', 'Рысь',
            'Северная Корона', 'Стрела', 'Телец', 'Треугольник', 'Цефей', 'Ящерица']

    if request.method == "POST":
        bar = request.form['geturl']
        bar = bar.replace(' ', '')
        print(bar)
        name = bar + '.html'
        return render_template(name, title='Созвездие')
    else:
        text = ""
        return render_template('page2.html', option=list, text=text, title='Выбор созвездия')


if __name__ == '__main__':
    main()
